package com.example.flutter_project2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
